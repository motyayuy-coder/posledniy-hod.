# Последний ход — Android

Android-проект игры на Kotlin. Для получения APK без компьютера смотри **BUILD-APK-ON-PHONE-RU.md**: проект содержит GitHub Actions workflow, который собирает APK на сервере и прикладывает его как Artifact.

Локальная сборка (если есть Android Studio): открыть папку проекта и выполнить `gradle assembleDebug` либо Build → Build APK(s). Результат: `app/build/outputs/apk/debug/app-debug.apk`.

Важно: исходники подготовлены, но APK не считается проверенным, пока облачная сборка не завершится успешно и игра не будет запущена на устройстве.
