package com.example.posledniyhod

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.Context
import android.graphics.Color
import android.view.WindowManager
import kotlin.math.min
import kotlin.random.Random

private const val PREFS = "voluntary_exit_only"
private const val SAVE_KEY = "manual_save"

data class GameState(
    var round: Int = 1,
    var score: Int = 0,
    var youHp: Int = 3,
    var aiHp: Int = 3,
    var turn: Int = 0, // 0 player, 1 AI
    var stake: Int = 1,
    var danger: Int = 2,
    var blanks: Int = 4,
    var items: MutableList<String> = mutableListOf("Осмотр", "Кофе"),
    var message: String = "Стол ждёт. Выбирай действие осторожно.",
    var over: Boolean = false
)

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var message: TextView
    private lateinit var itemsText: TextView
    private lateinit var logText: TextView
    private lateinit var state: GameState
    private val history = mutableListOf<String>()
    private var sessionEnded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 10, 9)
        window.navigationBarColor = Color.rgb(12, 10, 9)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        state = loadManualSave() ?: GameState()
        buildUi()
        render()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 10, 9))
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(TextView(this).apply {
            text = "ПСИХОЛОГИЧЕСКАЯ ИГРА  •  № 001"
            textSize = 11f; letterSpacing = .15f; setTextColor(Color.rgb(180, 151, 105))
        })
        content.addView(TextView(this).apply {
            text = "ПОСЛЕДНИЙ\nХОД"
            textSize = 42f; setTextColor(Color.rgb(239, 229, 210))
            typeface = Typeface.create("serif", Typeface.BOLD); setLineSpacing(-8f, 1f)
            setPadding(0, dp(8), 0, dp(4))
        })
        content.addView(TextView(this).apply {
            text = "ОДИН ПРОМАХ — И ВСЁ СНАЧАЛА"
            textSize = 12f; letterSpacing = .08f; setTextColor(Color.rgb(159, 144, 126))
            setPadding(0, 0, 0, dp(16))
        })

        content.addView(TableView(this), LinearLayout.LayoutParams(-1, dp(180)))
        status = panelText(15f, Color.rgb(230, 207, 158))
        status.setPadding(dp(14), dp(12), dp(14), dp(12))
        content.addView(status, marginParams(top = 12))
        message = panelText(14f, Color.rgb(222, 216, 205))
        message.setPadding(dp(14), dp(12), dp(14), dp(12))
        content.addView(message, marginParams(top = 8))
        itemsText = panelText(13f, Color.rgb(193, 182, 163))
        itemsText.setPadding(dp(14), dp(12), dp(14), dp(12))
        content.addView(itemsText, marginParams(top = 8))

        val row1 = buttonRow()
        row1.addView(gameButton("Рискнуть", true) { takeTurn() }, weightParams())
        row1.addView(gameButton("Оценить стол") { inspect() }, weightParams())
        content.addView(row1, marginParams(top = 12))

        val row2 = buttonRow()
        row2.addView(gameButton("Использовать предмет") { useItem() }, weightParams())
        row2.addView(gameButton("Передать ход") { passTurn() }, weightParams())
        content.addView(row2, marginParams(top = 8))

        logText = panelText(12f, Color.rgb(144, 135, 121))
        logText.setPadding(dp(14), dp(12), dp(14), dp(12))
        content.addView(logText, marginParams(top = 10))

        val row3 = buttonRow()
        row3.addView(gameButton("Выйти и сохранить") { voluntaryExit() }, weightParams())
        row3.addView(gameButton("Сбросить забег") { resetRun() }, weightParams())
        content.addView(row3, marginParams(top = 14))
        content.addView(TextView(this).apply {
            text = "Прогресс не сохраняется автоматически. Сохранение создаётся только кнопкой добровольного выхода."
            textSize = 11f; setTextColor(Color.rgb(109, 102, 93))
            setPadding(dp(2), dp(10), dp(2), 0)
        })
        setContentView(root)
    }

    private fun panelText(size: Float, color: Int) = TextView(this).apply {
        textSize = size; setTextColor(color)
        setBackgroundColor(Color.rgb(28, 24, 21))
    }
    private fun buttonRow() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
    private fun gameButton(label: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false
        setTextColor(if (primary) Color.rgb(255, 241, 222) else Color.rgb(225, 211, 187))
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(
            if (primary) Color.rgb(126, 42, 35) else Color.rgb(54, 43, 34)))
        setOnClickListener { if (!state.over) action() }
    }
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(50), 1f).apply {
        marginEnd = dp(5); marginStart = dp(5)
    }
    private fun marginParams(top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun render() {
        status.text = "РАУНД ${state.round}     ОЧКИ ${state.score}     СТАВКА ${state.stake}×\n" +
                "ТЫ: ${"● ".repeat(state.youHp.coerceAtLeast(0))}     СОПЕРНИК: ${"● ".repeat(state.aiHp.coerceAtLeast(0))}" +
                if (state.turn == 0) "\nТВОЙ ХОД" else "\nХОД СОПЕРНИКА"
        message.text = state.message
        itemsText.text = "ПРЕДМЕТЫ: " + if (state.items.isEmpty()) "нет" else state.items.joinToString("  •  ")
        logText.text = "ЖУРНАЛ\n" + history.takeLast(6).joinToString("\n") { "— $it" }
        root.invalidate()
    }

    private fun addLog(s: String) { history.add(0, s); if (history.size > 20) history.removeAt(history.lastIndex) }

    private fun takeTurn() {
        if (state.turn != 0 || state.over) return
        if (Random.nextInt(state.danger + state.blanks) < state.danger) {
            state.message = "ПРОМАХ. Забег обнулён. Никаких вторых попыток."
            addLog("Ты ошибся. Весь забег потерян.")
            render()
            AlertDialog.Builder(this).setTitle("ЗАБЕГ ОБНУЛЁН")
                .setMessage("Один промах — и всё с самого начала.")
                .setCancelable(false)
                .setPositiveButton("Начать с нуля") { _, _ -> hardReset() }
                .show()
        } else {
            state.score += state.stake * 2
            state.stake = (state.stake + 1).coerceAtMost(9)
            state.blanks = (state.blanks - 1).coerceAtLeast(0)
            state.danger = (state.danger - 1).coerceAtLeast(1)
            state.message = "Чистый ход. Очки начислены. Теперь ход соперника."
            addLog("Ты прошёл ход: +${state.stake * 2} очков.")
            state.turn = 1
            render()
            android.os.Handler(mainLooper).postDelayed({ aiTurn() }, 700)
        }
    }

    private fun aiTurn() {
        if (state.over || state.turn != 1) return
        // AI weighs risk, current score, and its remaining health.
        val riskyChoice = state.aiHp <= 1 || (state.score > state.round * 8 && Random.nextBoolean())
        val dangerChance = state.danger.toFloat() / (state.danger + state.blanks).coerceAtLeast(1)
        val fail = if (riskyChoice) Random.nextFloat() < dangerChance else Random.nextFloat() < dangerChance * .65f
        if (fail) {
            state.aiHp--
            addLog("Соперник ошибся и потерял здоровье.")
            if (state.aiHp <= 0) {
                state.score += 10
                state.round++
                state.youHp = 3; state.aiHp = 3; state.danger = 2; state.blanks = 4
                state.stake = 1; state.turn = 0
                state.items.add(if (state.round % 2 == 0) "Страховка" else "Осмотр")
                state.message = "Раунд выигран. Получен предмет. Следующий стол готов."
            } else {
                state.turn = 0
                state.message = "Соперник промахнулся. Твой ход."
            }
        } else {
            state.blanks = (state.blanks - 1).coerceAtLeast(0)
            state.danger = (state.danger - 1).coerceAtLeast(1)
            state.turn = 0
            state.message = "Соперник пережил ход. Твой ход."
        }
        if (state.blanks == 0 && state.danger == 1) { state.blanks = 4; state.danger = 2 }
        render()
    }

    private fun inspect() {
        val total = state.danger + state.blanks
        state.message = "ОЦЕНКА СТОЛА: опасных символов — ${state.danger}, безопасных — ${state.blanks}. Шанс опасного исхода около ${state.danger * 100 / total}%."
        addLog("Ты осмотрел стол.")
        render()
    }

    private fun useItem() {
        if (state.items.isEmpty()) { state.message = "Предметов нет. Выигрывай раунды, чтобы получать новые."; render(); return }
        val choices = state.items.toTypedArray()
        AlertDialog.Builder(this).setTitle("Выбери предмет").setItems(choices) { _, which ->
            val item = state.items.removeAt(which)
            when (item) {
                "Осмотр" -> { state.message = "Осмотр: опасных ${state.danger}, безопасных ${state.blanks}. Следующий ход за тобой."; }
                "Кофе" -> { state.stake = (state.stake + 1).coerceAtMost(9); state.message = "Кофе помог собраться. Ставка увеличена на 1."; }
                "Страховка" -> { state.blanks += 1; state.message = "Страховка добавила один безопасный символ в барабан."; }
                else -> state.message = "Предмет использован."
            }
            addLog("Использован предмет: $item.")
            render()
        }.show()
    }

    private fun passTurn() {
        if (state.turn != 0) return
        state.message = "Ты решил выждать. Соперник делает ход."
        state.turn = 1
        render()
        android.os.Handler(mainLooper).postDelayed({ aiTurn() }, 450)
    }

    private fun loadManualSave(): GameState? {
        val raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(SAVE_KEY, null) ?: return null
        return try {
            val parts = raw.split("|", limit = 3)
            val nums = parts[0].split(",").map { it.toInt() }
            val loaded = GameState(
                round = nums[0], score = nums[1], youHp = nums[2], aiHp = nums[3],
                turn = nums[4], stake = nums[5], danger = nums[6], blanks = nums[7],
                items = if (parts.size > 1 && parts[1].isNotEmpty()) parts[1].split(";").toMutableList() else mutableListOf(),
                message = if (parts.size > 2) parts[2] else "Загружено добровольное сохранение."
            )
            history.clear()
            history.add("Загружено сохранение, созданное при добровольном выходе.")
            loaded
        } catch (_: Exception) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(SAVE_KEY).commit()
            null
        }
    }

    private fun voluntaryExit() {
        val data = listOf(state.round, state.score, state.youHp, state.aiHp, state.turn, state.stake, state.danger, state.blanks).joinToString(",") +
                "|" + state.items.joinToString(";") + "|" + state.message.replace("|", " ")
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(SAVE_KEY, data).commit()
        AlertDialog.Builder(this).setTitle("Прогресс сохранён")
            .setMessage("Сохранение создано по твоей команде. При следующем запуске его можно загрузить.")
            .setPositiveButton("Выйти") { _, _ -> sessionEnded = true; finish() }
            .setNegativeButton("Остаться") { _, _ -> render() }.show()
    }

    private fun resetRun() {
        AlertDialog.Builder(this).setTitle("Сбросить весь забег?")
            .setMessage("Очки и раунды будут потеряны.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сбросить") { _, _ -> hardReset() }.show()
    }

    private fun hardReset() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove(SAVE_KEY).commit()
        state = GameState()
        history.clear()
        addLog("Новый забег начат.")
        render()
    }

    override fun onBackPressed() {
        AlertDialog.Builder(this).setTitle("Выйти из забега?")
            .setMessage("Прогресс сохранится только если подтвердить добровольный выход.")
            .setNegativeButton("Продолжить", null)
            .setPositiveButton("Выйти и сохранить") { _, _ -> voluntaryExit() }
            .show()
    }

    inner class TableView(context: Context) : View(context) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            p.shader = LinearGradient(0f, 0f, w, h, Color.rgb(88, 43, 29), Color.rgb(24, 14, 12), Shader.TileMode.CLAMP)
            canvas.drawRoundRect(RectF(0f, 0f, w, h), 18f, 18f, p); p.shader = null
            p.color = Color.rgb(116, 75, 49); p.style = Paint.Style.STROKE; p.strokeWidth = 2f
            canvas.drawRoundRect(RectF(8f, 8f, w-8f, h-8f), 15f, 15f, p); p.style = Paint.Style.FILL
            // Warm overhead lamp glow
            p.shader = android.graphics.RadialGradient(w*.5f, h*.22f, w*.58f, intArrayOf(0x33ffd99a, 0x00ffd99a), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, p); p.shader = null
            p.color = Color.rgb(231, 211, 176); p.textAlign = Paint.Align.CENTER
            p.typeface = Typeface.create("serif", Typeface.BOLD); p.textSize = 18f
            canvas.drawText("THE LAST MOVE", w/2, 34f, p)
            p.color = Color.rgb(211, 190, 155); p.textSize = 11f; p.typeface = Typeface.DEFAULT
            canvas.drawText("ТВОЙ СТОЛ  •  РАУНД ${state.round}", w/2, 53f, p)
            // Table objects: brass tokens, cards and a sealed case
            for (i in 0..4) {
                val x = w*.22f + i*w*.14f
                p.color = if (i < state.danger) Color.rgb(158, 50, 42) else Color.rgb(180, 151, 95)
                canvas.drawCircle(x, h*.62f, 12f, p)
                p.color = Color.rgb(35, 25, 20); canvas.drawCircle(x, h*.62f, 7f, p)
                p.color = if (i < state.danger) Color.rgb(210, 76, 61) else Color.rgb(218, 191, 132)
                canvas.drawCircle(x, h*.62f, 3f, p)
            }
            p.color = Color.rgb(22, 18, 16); canvas.drawRoundRect(RectF(w*.32f,h*.75f,w*.68f,h*.92f),5f,5f,p)
            p.color = Color.rgb(153, 118, 75); p.style = Paint.Style.STROKE; p.strokeWidth=1.5f
            canvas.drawRoundRect(RectF(w*.32f,h*.75f,w*.68f,h*.92f),5f,5f,p); p.style=Paint.Style.FILL
            p.color = Color.rgb(194, 161, 107); p.textSize=10f
            canvas.drawText("SEALED CASE",w/2,h*.85f,p)
        }
    }
}
